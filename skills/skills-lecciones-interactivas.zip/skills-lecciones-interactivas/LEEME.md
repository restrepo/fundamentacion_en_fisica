# Skills para reproducir las lecciones interactivas

Lecciones de «Fundamentación en Física»: https://restrepo.github.io/fundamentacion_en_fisica/
Repositorio: https://github.com/restrepo/fundamentacion_en_fisica

## Contenido

| Archivo | Para qué |
|---|---|
| leccion-a-deck.skill | Construye la lección: un único HTML autocontenido con navegación, MathJax sin conexión, exploradores, ventanas emergentes, siglas y vista de profesor (`?profesor`, tecla N). |
| metodologias-activas.skill | Decide qué actividad poner y dónde, audita la lección y genera y analiza las pruebas de entrada y salida. |
| boton-formulario.skill | Botón «📷 Enviar…» que toma una captura de la diapositiva y abre un formulario de Google para entregarla. |
| google-form-popup.skill | Formulario de Google en una ventana emergente (votaciones de instrucción entre pares). |
| actualizar-repositorio.skill | Regenera las lecciones y prepara la actualización del repositorio (o el zip cuando no hay acceso de escritura). |
| _ds/ | Sistema de diseño de las lecciones (colores por variables CSS, tipografías). |

## Instalación

- **claude.ai:** Configuración → Capacidades → Skills → «Subir skill», un archivo `.skill` a la vez.
- **Claude Code:** descomprime cada `.skill` (es un zip) en `~/.claude/skills/` o en `.claude/skills/` del proyecto.

## Uso

1. Pon la fuente de una lección en `fuentes/<slug>/leccion-fuente.html` y el sistema de diseño en `fuentes/_ds/`.
2. Pide a Claude «aplicar el diseño» o «construir la lección»; la skill `leccion-a-deck` hace el resto
   (`scripts/build_html.py`), y `scripts/verificar_html.py` revisa fórmulas, cromo y desbordes.
3. Para añadir actividades: `scripts/nueva_actividad.py FUENTE spec.json` (ver `references/actividades.md`).

Diseño de material de estudio · W. Alexander Flórez
